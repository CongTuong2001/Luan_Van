export const API_URL = "http://localhost:5001";

